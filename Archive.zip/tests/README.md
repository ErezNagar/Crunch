Crunch!
=======

*@path /tests*
Test procedure for new builds
-----------------------------

1. Turn off minification.
2. Crunch [tests.less](tests.less) as "tests.css" and put it on the same path.
3. Verify MD5 checksum.
4. Cross fingers.
5. Rinse & repeat.

*View the [md5 of the expected output](tests.css.md5).*

*View the [CRC32 of the expected output](tests.css.sfv).*