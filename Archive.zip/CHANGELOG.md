# 1.8
---
- LESS.js is now 1.6.0
- Bug fixes to setting project paths
- Lighter project build (1 MB removed)
- Update to AIR core libs
- Removed HTTP-style file handling (switched to fileLoader overriding) for @imports

# 1.7.1
---
- Fixed issue (#84) with copy/paste for the final time, we swear!
- Known Issue: Because nothing says &apos;great web support&apos; like Windows, Crunch unfortunately crashes if you try to paste in a line that's too long.
